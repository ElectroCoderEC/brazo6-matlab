function varargout = proyecto(varargin)
% PROYECTO MATLAB code for proyecto.fig
%      PROYECTO, by itself, creates a new PROYECTO or raises the existing
%      singleton*.
%
%      H = PROYECTO returns the handle to a new PROYECTO or the handle to
%      the existing singleton*.
%
%      PROYECTO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROYECTO.M with the given input arguments.
%
%      PROYECTO('Property','Value',...) creates a new PROYECTO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before proyecto_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to proyecto_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help proyecto

% Last Modified by GUIDE v2.5 07-Jul-2018 17:31:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @proyecto_OpeningFcn, ...
                   'gui_OutputFcn',  @proyecto_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before proyecto is made visible.
function proyecto_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to proyecto (see VARARGIN)

% Choose default command line output for proyecto
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes proyecto wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = proyecto_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in BASED.
function BASED_Callback(hObject, eventdata, handles)
% hObject    handle to BASED (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;
a.analogWrite(10,0); 
a.analogWrite(11,120);
pause(pau)
a.digitalWrite(10,0); 
a.digitalWrite(11,0);


% --- Executes on button press in BRAZO1DOWN.
function BRAZO1DOWN_Callback(hObject, eventdata, handles)
% hObject    handle to BRAZO1DOWN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;
a.digitalWrite(9,0);  
a.digitalWrite(8,1);
pause(pau)
a.digitalWrite(9,0);  
a.digitalWrite(8,0);

% --- Executes on button press in BASEI.
function BASEI_Callback(hObject, eventdata, handles)
% hObject    handle to BASEI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;
a.analogWrite(10,125); 
a.analogWrite(11,0);
pause(pau);
a.digitalWrite(10,0); 
a.digitalWrite(11,0);


% --- Executes on button press in BRAZO1UP.
function BRAZO1UP_Callback(hObject, eventdata, handles)
% hObject    handle to BRAZO1UP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;
a.digitalWrite(9,1);  
a.digitalWrite(8,0);
pause(pau)
a.digitalWrite(9,0);  
a.digitalWrite(8,0);

% --- Executes on button press in SALIR.
function SALIR_Callback(hObject, eventdata, handles)
% hObject    handle to SALIR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a;
delete(a);
hfig=get(0,'CurrentFigure');
delete(hfig);

% --- Executes on button press in CONECTAR.
function CONECTAR_Callback(hObject, eventdata, handles)
% hObject    handle to CONECTAR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
install_arduino      % Archivo para permitir conexion entre interfaces MATLAB y arduino
global a pau;            % declaracion de variable para asignar la placa arduino
a=arduino('COM2');   % se abre el puerto COM para la comunicacion y 
pau=0.3;                    % permite la normal programacion del arduino 
 
% HABILITAR BOTONES PARA EL CONTROL==================================
 set(handles.BASEI,'Enable','on') 
 set(handles.BASED,'Enable','on') 
 set(handles.BRAZO1UP,'Enable','on') 
 set(handles.BRAZO1DOWN,'Enable','on') 
 set(handles.BRAZO2UP,'Enable','on')
 set(handles.BRAZO2DOWN,'Enable','on') 
 set(handles.PALAR,'Enable','on')
 set(handles.PALAS,'Enable','on') 
 set(handles.SALIR,'Enable','on')
 set(handles.STOPB,'Enable','on') 
 set(handles.STOPB1,'Enable','on') 
 set(handles.STOPB2,'Enable','on') 
 set(handles.STOPP,'Enable','on') 
 set(handles.CONECTAR,'Enable','off') 
%====================================================================

%Indicar pines a usar como salidas ============================ 
a.pinMode(4,'output');  
a.pinMode(5,'output');  
a.pinMode(6,'output');  
a.pinMode(7,'output');  
a.pinMode(8,'output');  
a.pinMode(9,'output');  
a.pinMode(10,'output');  
a.pinMode(11,'output');  

%Se inicializan los pines de salida con valor LOW o cero ============================ 
a.digitalWrite(4,0);  
a.digitalWrite(5,0);
a.digitalWrite(6,0);  
a.digitalWrite(7,0);
a.digitalWrite(8,0);  
a.digitalWrite(9,0);
a.digitalWrite(10,0);
a.digitalWrite(11,0);
%====================================================================
 
% --- Executes on button press in BRAZO2UP.
function BRAZO2UP_Callback(hObject, eventdata, handles)
% hObject    handle to BRAZO2UP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;  % variable arduino 
a.digitalWrite(7,1);  
a.digitalWrite(6,0);
pause(pau)
a.digitalWrite(7,0);  
a.digitalWrite(6,0);



% --- Executes on button press in BRAZO2DOWN.
function BRAZO2DOWN_Callback(hObject, eventdata, handles)
% hObject    handle to BRAZO2DOWN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;
a.digitalWrite(7,0);  
a.digitalWrite(6,1);
pause(pau)
a.digitalWrite(7,0);  
a.digitalWrite(6,0);


% --- Executes on button press in PALAR.
function PALAR_Callback(hObject, eventdata, handles)
% hObject    handle to PALAR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;
a.digitalWrite(5,1);
a.digitalWrite(4,0);
pause(pau)
a.digitalWrite(5,0);
a.digitalWrite(4,0);

% --- Executes on button press in PALAS.
function PALAS_Callback(hObject, eventdata, handles)
% hObject    handle to PALAS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a pau;
a.digitalWrite(5,0);
a.digitalWrite(4,1);
pause(pau)
a.digitalWrite(5,0);
a.digitalWrite(4,0);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text2.
function text2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in STOPB.
function STOPB_Callback(hObject, eventdata, handles)
% hObject    handle to STOPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a;
a.digitalWrite(11,0);
a.digitalWrite(10,0);

% --- Executes on button press in STOPB1.
function STOPB1_Callback(hObject, eventdata, handles)
% hObject    handle to STOPB1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a;
a.digitalWrite(9,0);  
a.digitalWrite(8,0);

% --- Executes on button press in STOPB2.
function STOPB2_Callback(hObject, eventdata, handles)
% hObject    handle to STOPB2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a;
a.digitalWrite(7,0);  
a.digitalWrite(6,0);


% --- Executes on button press in STOPP.
function STOPP_Callback(hObject, eventdata, handles)
% hObject    handle to STOPP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a;
a.digitalWrite(5,0);
a.digitalWrite(4,0);
