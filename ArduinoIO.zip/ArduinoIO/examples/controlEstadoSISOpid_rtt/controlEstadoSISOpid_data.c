/*
 * File: controlEstadoSISOpid_data.c
 *
 * Code generated for Simulink model 'controlEstadoSISOpid'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * TLC version                    : 8.8 (Jan 20 2015)
 * C/C++ source code generated on : Mon Jul 31 18:07:51 2017
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controlEstadoSISOpid.h"
#include "controlEstadoSISOpid_private.h"

/* Block parameters (auto storage) */
P_controlEstadoSISOpid_T controlEstadoSISOpid_P = {
  0.001,                               /* Mask Parameter: DiscretePIDController_I
                                        * Referenced by: '<S2>/Integral Gain'
                                        */
  0.0,                                 /* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                        * Referenced by: '<S1>/UD'
                                        */
  0.04,                                /* Mask Parameter: DiscretePIDController_P
                                        * Referenced by: '<S2>/Proportional Gain'
                                        */
  13.8249,                             /* Mask Parameter: Referencia_gain
                                        * Referenced by: '<S5>/Slider Gain'
                                        */
  13U,                                 /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S4>/PWM'
                                        */
  1.0,                                 /* Expression: param.A
                                        * Referenced by: '<S9>/Constant3'
                                        */
  1.0,                                 /* Expression: param.H
                                        * Referenced by: '<S9>/Hcst'
                                        */
  1.0,                                 /* Expression: param.Ht
                                        * Referenced by: '<S9>/Hcst_t'
                                        */
  1.0,                                 /* Expression: param.R
                                        * Referenced by: '<S9>/Constant2'
                                        */
  1.0,                                 /* Expression: param.At
                                        * Referenced by: '<S9>/Constant4'
                                        */
  0.02,                                /* Expression: param.Q
                                        * Referenced by: '<S9>/Constant5'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  0.48875855327468232,                 /* Expression: 500/1023
                                        * Referenced by: '<Root>/Gain2'
                                        */
  0.0,                                 /* Expression: param.XAll
                                        * Referenced by: '<S3>/Unit Delay2'
                                        */
  10.02,                               /* Expression: param.PAll
                                        * Referenced by: '<S3>/Unit Delay3'
                                        */
  0.03,                                /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S2>/Integrator'
                                        */
  0.0,                                 /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S2>/Integrator'
                                        */
  33.333333333333336,                  /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S1>/TSamp'
                                        */
  0.01,                                /* Expression: 0.01
                                        * Referenced by: '<Root>/Gain1'
                                        */
  -100.0,                              /* Expression: -100
                                        * Referenced by: '<Root>/Gain3'
                                        */
  255.0,                               /* Expression: 255
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  1,                                   /* Computed Parameter: Iterator_IterationLimit
                                        * Referenced by: '<S7>/Iterator'
                                        */
  0U                                   /* Computed Parameter: AnalogInput1_p1
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
