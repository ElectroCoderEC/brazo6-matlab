/*
 * File: controlEstadoSISOpid.h
 *
 * Code generated for Simulink model 'controlEstadoSISOpid'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * TLC version                    : 8.8 (Jan 20 2015)
 * C/C++ source code generated on : Mon Jul 31 18:07:51 2017
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controlEstadoSISOpid_h_
#define RTW_HEADER_controlEstadoSISOpid_h_
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef controlEstadoSISOpid_COMMON_INCLUDES_
# define controlEstadoSISOpid_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "arduino_analoginput_lct.h"
#include "arduino_analogoutput_lct.h"
#endif                                 /* controlEstadoSISOpid_COMMON_INCLUDES_ */

#include "controlEstadoSISOpid_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T SliderGain;                   /* '<S5>/Slider Gain' */
  real_T Sum2;                         /* '<Root>/Sum2' */
  real_T TSamp;                        /* '<S1>/TSamp' */
  real_T Gain3;                        /* '<Root>/Gain3' */
  real_T Saturation1;                  /* '<Root>/Saturation1' */
  real_T IntegralGain;                 /* '<S2>/Integral Gain' */
  real_T Assignment;                   /* '<S10>/Assignment' */
  real_T Assignment_e;                 /* '<S11>/Assignment' */
  real_T Assignment_i;                 /* '<S12>/Assignment' */
} B_controlEstadoSISOpid_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay2_DSTATE;            /* '<S3>/Unit Delay2' */
  real_T UnitDelay3_DSTATE;            /* '<S3>/Unit Delay3' */
  real_T Integrator_DSTATE;            /* '<S2>/Integrator' */
  real_T UD_DSTATE;                    /* '<S1>/UD' */
  real_T LDLFactorization_VMX;         /* '<S13>/LDL Factorization' */
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<Root>/Scope' */

  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<Root>/Scope1' */

  boolean_T LDLFactorization_STATE;    /* '<S13>/LDL Factorization' */
} DW_controlEstadoSISOpid_T;

/* Parameters (auto storage) */
struct P_controlEstadoSISOpid_T_ {
  real_T DiscretePIDController_I;      /* Mask Parameter: DiscretePIDController_I
                                        * Referenced by: '<S2>/Integral Gain'
                                        */
  real_T DiscreteDerivative_ICPrevScaled;/* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                          * Referenced by: '<S1>/UD'
                                          */
  real_T DiscretePIDController_P;      /* Mask Parameter: DiscretePIDController_P
                                        * Referenced by: '<S2>/Proportional Gain'
                                        */
  real_T Referencia_gain;              /* Mask Parameter: Referencia_gain
                                        * Referenced by: '<S5>/Slider Gain'
                                        */
  uint32_T PWM_pinNumber;              /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S4>/PWM'
                                        */
  real_T Constant3_Value;              /* Expression: param.A
                                        * Referenced by: '<S9>/Constant3'
                                        */
  real_T Hcst_Value;                   /* Expression: param.H
                                        * Referenced by: '<S9>/Hcst'
                                        */
  real_T Hcst_t_Value;                 /* Expression: param.Ht
                                        * Referenced by: '<S9>/Hcst_t'
                                        */
  real_T Constant2_Value;              /* Expression: param.R
                                        * Referenced by: '<S9>/Constant2'
                                        */
  real_T Constant4_Value;              /* Expression: param.At
                                        * Referenced by: '<S9>/Constant4'
                                        */
  real_T Constant5_Value;              /* Expression: param.Q
                                        * Referenced by: '<S9>/Constant5'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Gain2_Gain;                   /* Expression: 500/1023
                                        * Referenced by: '<Root>/Gain2'
                                        */
  real_T UnitDelay2_InitialCondition;  /* Expression: param.XAll
                                        * Referenced by: '<S3>/Unit Delay2'
                                        */
  real_T UnitDelay3_InitialCondition;  /* Expression: param.PAll
                                        * Referenced by: '<S3>/Unit Delay3'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S2>/Integrator'
                                        */
  real_T Integrator_IC;                /* Expression: InitialConditionForIntegrator
                                        * Referenced by: '<S2>/Integrator'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S1>/TSamp'
                                        */
  real_T Gain1_Gain;                   /* Expression: 0.01
                                        * Referenced by: '<Root>/Gain1'
                                        */
  real_T Gain3_Gain;                   /* Expression: -100
                                        * Referenced by: '<Root>/Gain3'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 255
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: 0
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  int32_T Iterator_IterationLimit;     /* Computed Parameter: Iterator_IterationLimit
                                        * Referenced by: '<S7>/Iterator'
                                        */
  uint32_T AnalogInput1_p1;            /* Computed Parameter: AnalogInput1_p1
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_controlEstadoSISOpid_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (auto storage) */
extern P_controlEstadoSISOpid_T controlEstadoSISOpid_P;

/* Block signals (auto storage) */
extern B_controlEstadoSISOpid_T controlEstadoSISOpid_B;

/* Block states (auto storage) */
extern DW_controlEstadoSISOpid_T controlEstadoSISOpid_DW;

/* Model entry point functions */
extern void controlEstadoSISOpid_initialize(void);
extern void controlEstadoSISOpid_output(void);
extern void controlEstadoSISOpid_update(void);
extern void controlEstadoSISOpid_terminate(void);

/* Real-time Model object */
extern RT_MODEL_controlEstadoSISOpid_T *const controlEstadoSISOpid_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'controlEstadoSISOpid'
 * '<S1>'   : 'controlEstadoSISOpid/Discrete Derivative'
 * '<S2>'   : 'controlEstadoSISOpid/Discrete PID Controller'
 * '<S3>'   : 'controlEstadoSISOpid/Kalman Filter1'
 * '<S4>'   : 'controlEstadoSISOpid/PWM'
 * '<S5>'   : 'controlEstadoSISOpid/Referencia'
 * '<S6>'   : 'controlEstadoSISOpid/Kalman Filter1/Check Signal Attributes'
 * '<S7>'   : 'controlEstadoSISOpid/Kalman Filter1/Control'
 * '<S8>'   : 'controlEstadoSISOpid/Kalman Filter1/Control/Options'
 * '<S9>'   : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/Core'
 * '<S10>'  : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/P_prd_Assign'
 * '<S11>'  : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/X_prd_Assign'
 * '<S12>'  : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/Z_est_Assign'
 * '<S13>'  : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/Core/LDL Solver'
 * '<S14>'  : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/Core/LDL Solver/Check Signal Attributes'
 * '<S15>'  : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/Core/LDL Solver/Check Signal Attributes1'
 * '<S16>'  : 'controlEstadoSISOpid/Kalman Filter1/Control/Options/Core/LDL Solver/Check Signal Attributes2'
 */
#endif                                 /* RTW_HEADER_controlEstadoSISOpid_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
