/*
 * File: controlEstadoSISOpid.c
 *
 * Code generated for Simulink model 'controlEstadoSISOpid'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * TLC version                    : 8.8 (Jan 20 2015)
 * C/C++ source code generated on : Mon Jul 31 18:07:51 2017
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "controlEstadoSISOpid.h"
#include "controlEstadoSISOpid_private.h"
#include "controlEstadoSISOpid_dt.h"

/* Block signals (auto storage) */
B_controlEstadoSISOpid_T controlEstadoSISOpid_B;

/* Block states (auto storage) */
DW_controlEstadoSISOpid_T controlEstadoSISOpid_DW;

/* Real-time model */
RT_MODEL_controlEstadoSISOpid_T controlEstadoSISOpid_M_;
RT_MODEL_controlEstadoSISOpid_T *const controlEstadoSISOpid_M =
  &controlEstadoSISOpid_M_;
void LDLf_int32_Treal_T(real_T out[], real_T vArray[], const int32_T nRows,
  const real_T in[])
{
  int32_T c;
  int32_T r;
  int32_T idx1;
  int32_T idx2;
  real_T mYTmp;
  real_T mYTmpR;
  boolean_T done;
  int32_T k;
  real_T prod;

  /* S-Function (sdspldl2): '<S13>/LDL Factorization' */
  done = false;

  /* use done to control the for loop return early  */
  /* when non-positive definite eigenvalue is detected */
  c = 0L;
  while ((c < nRows) && (!done)) {
    idx2 = c * nRows;
    for (r = 0L; r < c; r++) {
      idx1 = r * nRows;
      mYTmp = out[idx1 + c];
      mYTmpR = out[idx1 + r];
      vArray[r] = mYTmp * mYTmpR;
    }

    mYTmp = in[idx2 + c];
    idx1 = c;
    for (r = 0L; r < c; r++) {
      prod = out[idx1] * vArray[r];
      mYTmp -= prod;
      idx1 += nRows;
    }

    mYTmpR = mYTmp;
    if (mYTmp <= 0.0) {
      done = true;
    } else {
      out[idx2 + c] = mYTmp;
      for (r = c + 1L; (uint32_T)r < (uint32_T)nRows; r++) {
        mYTmp = in[idx2 + r];
        idx1 = r;
        for (k = 0L; k < c; k++) {
          prod = out[idx1] * vArray[k];
          mYTmp -= prod;
          idx1 += nRows;
        }

        out[idx2 + r] = mYTmp / mYTmpR;
      }
    }

    c++;
  }

  /* transpose and copy lower sub-triang to upper */
  c = 0L;
  while ((c < nRows) && (!done)) {
    for (r = c + 1L; (uint32_T)r < (uint32_T)nRows; r++) {
      mYTmp = out[c * nRows + r];
      out[r * nRows + c] = mYTmp;
    }

    c++;
  }

  /* End of S-Function (sdspldl2): '<S13>/LDL Factorization' */
}

/* Model output function */
void controlEstadoSISOpid_output(void)
{
  uint16_T rtb_AnalogInput1_0;
  real_T rtb_Gain2;
  int32_T s7_iter;
  real_T rtb_KZHX_prd;
  real_T rtb_Z_est_Multiply;
  uint8_T tmp;

  /* Gain: '<S5>/Slider Gain' incorporates:
   *  Constant: '<Root>/Constant'
   */
  controlEstadoSISOpid_B.SliderGain = controlEstadoSISOpid_P.Referencia_gain *
    controlEstadoSISOpid_P.Constant_Value;

  /* S-Function (arduinoanaloginput_sfcn): '<Root>/Analog Input1' */
  rtb_AnalogInput1_0 = MW_analogRead(controlEstadoSISOpid_P.AnalogInput1_p1);

  /* Gain: '<Root>/Gain2' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   *  S-Function (arduinoanaloginput_sfcn): '<Root>/Analog Input1'
   */
  rtb_Gain2 = controlEstadoSISOpid_P.Gain2_Gain * (real_T)rtb_AnalogInput1_0;

  /* Outputs for Iterator SubSystem: '<S3>/Control' incorporates:
   *  ForIterator: '<S7>/Iterator'
   */
  /* UnitDelay: '<S3>/Unit Delay3' */
  controlEstadoSISOpid_B.Assignment = controlEstadoSISOpid_DW.UnitDelay3_DSTATE;

  /* UnitDelay: '<S3>/Unit Delay2' */
  controlEstadoSISOpid_B.Assignment_e =
    controlEstadoSISOpid_DW.UnitDelay2_DSTATE;
  for (s7_iter = 1L; s7_iter <= controlEstadoSISOpid_P.Iterator_IterationLimit;
       s7_iter++) {
    /* Product: '<S9>/H*P_prdt' incorporates:
     *  Constant: '<S9>/Hcst'
     *  UnitDelay: '<S3>/Unit Delay3'
     */
    rtb_Z_est_Multiply = controlEstadoSISOpid_P.Hcst_Value *
      controlEstadoSISOpid_DW.UnitDelay3_DSTATE;

    /* Sum: '<S9>/H*P_prdt*Ht+R' incorporates:
     *  Constant: '<S9>/Constant2'
     *  Constant: '<S9>/Hcst_t'
     *  Product: '<S9>/H*P_prdt*Ht'
     */
    rtb_KZHX_prd = rtb_Z_est_Multiply * controlEstadoSISOpid_P.Hcst_t_Value +
      controlEstadoSISOpid_P.Constant2_Value;

    /* S-Function (sdspldl2): '<S13>/LDL Factorization' */
    LDLf_int32_Treal_T(&rtb_KZHX_prd,
                       &controlEstadoSISOpid_DW.LDLFactorization_VMX, 1L,
                       &rtb_KZHX_prd);

    /* S-Function (sdspdmult2): '<S13>/Matrix Scaling' incorporates:
     *  Math: '<S13>/Math Function'
     *  S-Function (sdspdiag2): '<S13>/Extract Diagonal'
     *
     * About '<S13>/Math Function':
     *  Operator: reciprocal
     */
    rtb_Z_est_Multiply *= 1.0 / rtb_KZHX_prd;

    /* Sum: '<S9>/X_prd+K*(Z-H*X_prd)' incorporates:
     *  Constant: '<S9>/Hcst'
     *  Product: '<S9>/H*X_prd'
     *  Product: '<S9>/K*(Z-H*X_prd)'
     *  Selector: '<S8>/Selector'
     *  Sum: '<S9>/Z-H*X_prd'
     *  UnitDelay: '<S3>/Unit Delay2'
     */
    rtb_KZHX_prd = (rtb_Gain2 - controlEstadoSISOpid_P.Hcst_Value *
                    controlEstadoSISOpid_DW.UnitDelay2_DSTATE) *
      rtb_Z_est_Multiply + controlEstadoSISOpid_DW.UnitDelay2_DSTATE;

    /* Assignment: '<S10>/Assignment' incorporates:
     *  Constant: '<S9>/Constant3'
     *  Constant: '<S9>/Constant4'
     *  Constant: '<S9>/Constant5'
     *  Constant: '<S9>/Hcst'
     *  Product: '<S9>/A*P*At'
     *  Product: '<S9>/K*H*P_prd'
     *  Sum: '<S9>/A*P*At+Q'
     *  Sum: '<S9>/P_prd-K*H*P_prd'
     *  UnitDelay: '<S3>/Unit Delay3'
     */
    controlEstadoSISOpid_B.Assignment =
      (controlEstadoSISOpid_DW.UnitDelay3_DSTATE -
       controlEstadoSISOpid_P.Hcst_Value *
       controlEstadoSISOpid_DW.UnitDelay3_DSTATE * rtb_Z_est_Multiply) *
      controlEstadoSISOpid_P.Constant4_Value *
      controlEstadoSISOpid_P.Constant3_Value +
      controlEstadoSISOpid_P.Constant5_Value;

    /* Assignment: '<S11>/Assignment' incorporates:
     *  Constant: '<S9>/Constant3'
     *  Product: '<S9>/A*X'
     */
    controlEstadoSISOpid_B.Assignment_e = controlEstadoSISOpid_P.Constant3_Value
      * rtb_KZHX_prd;

    /* Assignment: '<S12>/Assignment' incorporates:
     *  Constant: '<S9>/Hcst'
     *  Product: '<S9>/Z_est_Multiply'
     */
    controlEstadoSISOpid_B.Assignment_i = controlEstadoSISOpid_P.Hcst_Value *
      rtb_KZHX_prd;
  }

  /* End of Outputs for SubSystem: '<S3>/Control' */

  /* Sum: '<Root>/Sum2' */
  controlEstadoSISOpid_B.Sum2 = controlEstadoSISOpid_B.SliderGain -
    controlEstadoSISOpid_B.Assignment_i;

  /* SampleTimeMath: '<S1>/TSamp'
   *
   * About '<S1>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  controlEstadoSISOpid_B.TSamp = controlEstadoSISOpid_B.Assignment_i *
    controlEstadoSISOpid_P.TSamp_WtEt;

  /* Gain: '<Root>/Gain3' incorporates:
   *  DiscreteIntegrator: '<S2>/Integrator'
   *  Gain: '<Root>/Gain1'
   *  Gain: '<S2>/Proportional Gain'
   *  Sum: '<Root>/Sum3'
   *  Sum: '<S1>/Diff'
   *  Sum: '<S2>/Sum'
   *  UnitDelay: '<S1>/UD'
   */
  controlEstadoSISOpid_B.Gain3 =
    ((controlEstadoSISOpid_P.DiscretePIDController_P *
      controlEstadoSISOpid_B.Sum2 + controlEstadoSISOpid_DW.Integrator_DSTATE) +
     (controlEstadoSISOpid_B.TSamp - controlEstadoSISOpid_DW.UD_DSTATE) *
     controlEstadoSISOpid_P.Gain1_Gain) * controlEstadoSISOpid_P.Gain3_Gain;

  /* Saturate: '<Root>/Saturation1' */
  if (controlEstadoSISOpid_B.Gain3 > controlEstadoSISOpid_P.Saturation1_UpperSat)
  {
    controlEstadoSISOpid_B.Saturation1 =
      controlEstadoSISOpid_P.Saturation1_UpperSat;
  } else if (controlEstadoSISOpid_B.Gain3 <
             controlEstadoSISOpid_P.Saturation1_LowerSat) {
    controlEstadoSISOpid_B.Saturation1 =
      controlEstadoSISOpid_P.Saturation1_LowerSat;
  } else {
    controlEstadoSISOpid_B.Saturation1 = controlEstadoSISOpid_B.Gain3;
  }

  /* End of Saturate: '<Root>/Saturation1' */

  /* DataTypeConversion: '<S4>/Data Type Conversion' */
  if (controlEstadoSISOpid_B.Saturation1 < 256.0) {
    if (controlEstadoSISOpid_B.Saturation1 >= 0.0) {
      tmp = (uint8_T)controlEstadoSISOpid_B.Saturation1;
    } else {
      tmp = 0U;
    }
  } else {
    tmp = MAX_uint8_T;
  }

  /* End of DataTypeConversion: '<S4>/Data Type Conversion' */

  /* S-Function (arduinoanalogoutput_sfcn): '<S4>/PWM' */
  MW_analogWrite(controlEstadoSISOpid_P.PWM_pinNumber, tmp);

  /* Gain: '<S2>/Integral Gain' */
  controlEstadoSISOpid_B.IntegralGain =
    controlEstadoSISOpid_P.DiscretePIDController_I * controlEstadoSISOpid_B.Sum2;
}

/* Model update function */
void controlEstadoSISOpid_update(void)
{
  /* Update for UnitDelay: '<S3>/Unit Delay2' */
  controlEstadoSISOpid_DW.UnitDelay2_DSTATE =
    controlEstadoSISOpid_B.Assignment_e;

  /* Update for UnitDelay: '<S3>/Unit Delay3' */
  controlEstadoSISOpid_DW.UnitDelay3_DSTATE = controlEstadoSISOpid_B.Assignment;

  /* Update for DiscreteIntegrator: '<S2>/Integrator' */
  controlEstadoSISOpid_DW.Integrator_DSTATE +=
    controlEstadoSISOpid_P.Integrator_gainval *
    controlEstadoSISOpid_B.IntegralGain;

  /* Update for UnitDelay: '<S1>/UD' */
  controlEstadoSISOpid_DW.UD_DSTATE = controlEstadoSISOpid_B.TSamp;

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.03s, 0.0s] */
    if ((rtmGetTFinal(controlEstadoSISOpid_M)!=-1) &&
        !((rtmGetTFinal(controlEstadoSISOpid_M)-
           controlEstadoSISOpid_M->Timing.taskTime0) >
          controlEstadoSISOpid_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(controlEstadoSISOpid_M, "Simulation finished");
    }

    if (rtmGetStopRequested(controlEstadoSISOpid_M)) {
      rtmSetErrorStatus(controlEstadoSISOpid_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  controlEstadoSISOpid_M->Timing.taskTime0 =
    (++controlEstadoSISOpid_M->Timing.clockTick0) *
    controlEstadoSISOpid_M->Timing.stepSize0;
}

/* Model initialize function */
void controlEstadoSISOpid_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)controlEstadoSISOpid_M, 0,
                sizeof(RT_MODEL_controlEstadoSISOpid_T));
  rtmSetTFinal(controlEstadoSISOpid_M, -1);
  controlEstadoSISOpid_M->Timing.stepSize0 = 0.03;

  /* External mode info */
  controlEstadoSISOpid_M->Sizes.checksums[0] = (1991885112U);
  controlEstadoSISOpid_M->Sizes.checksums[1] = (54835925U);
  controlEstadoSISOpid_M->Sizes.checksums[2] = (1262197940U);
  controlEstadoSISOpid_M->Sizes.checksums[3] = (3496330506U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    controlEstadoSISOpid_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(controlEstadoSISOpid_M->extModeInfo,
      &controlEstadoSISOpid_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(controlEstadoSISOpid_M->extModeInfo,
                        controlEstadoSISOpid_M->Sizes.checksums);
    rteiSetTPtr(controlEstadoSISOpid_M->extModeInfo, rtmGetTPtr
                (controlEstadoSISOpid_M));
  }

  /* block I/O */
  (void) memset(((void *) &controlEstadoSISOpid_B), 0,
                sizeof(B_controlEstadoSISOpid_T));

  /* states (dwork) */
  (void) memset((void *)&controlEstadoSISOpid_DW, 0,
                sizeof(DW_controlEstadoSISOpid_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    controlEstadoSISOpid_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Start for S-Function (arduinoanaloginput_sfcn): '<Root>/Analog Input1' */
  MW_pinModeAnalogInput(controlEstadoSISOpid_P.AnalogInput1_p1);

  /* Start for S-Function (arduinoanalogoutput_sfcn): '<S4>/PWM' */
  MW_pinModeOutput(controlEstadoSISOpid_P.PWM_pinNumber);

  /* InitializeConditions for UnitDelay: '<S3>/Unit Delay2' */
  controlEstadoSISOpid_DW.UnitDelay2_DSTATE =
    controlEstadoSISOpid_P.UnitDelay2_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S3>/Unit Delay3' */
  controlEstadoSISOpid_DW.UnitDelay3_DSTATE =
    controlEstadoSISOpid_P.UnitDelay3_InitialCondition;

  /* InitializeConditions for DiscreteIntegrator: '<S2>/Integrator' */
  controlEstadoSISOpid_DW.Integrator_DSTATE =
    controlEstadoSISOpid_P.Integrator_IC;

  /* InitializeConditions for UnitDelay: '<S1>/UD' */
  controlEstadoSISOpid_DW.UD_DSTATE =
    controlEstadoSISOpid_P.DiscreteDerivative_ICPrevScaled;
}

/* Model terminate function */
void controlEstadoSISOpid_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
