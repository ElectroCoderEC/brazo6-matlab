/*
 * File: timerInterrupt.h
 *
 * Code generated for Simulink model 'controlEstadoSISOpid'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * TLC version                    : 8.8 (Jan 20 2015)
 * C/C++ source code generated on : Mon Jul 31 18:07:51 2017
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_timerInterrupt_h_
#define RTW_HEADER_timerInterrupt_h_
#include "Arduino.h"
#define disable_Timer_Interrupt        (0)
#define enable_Timer_Interrupt         (0)
#endif                                 /* RTW_HEADER_timerInterrupt_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
