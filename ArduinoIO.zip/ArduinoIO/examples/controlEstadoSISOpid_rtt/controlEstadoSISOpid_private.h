/*
 * File: controlEstadoSISOpid_private.h
 *
 * Code generated for Simulink model 'controlEstadoSISOpid'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * TLC version                    : 8.8 (Jan 20 2015)
 * C/C++ source code generated on : Mon Jul 31 18:07:51 2017
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_controlEstadoSISOpid_private_h_
#define RTW_HEADER_controlEstadoSISOpid_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

extern void LDLf_int32_Treal_T(real_T out[], real_T vArray[], const int32_T
  nRows, const real_T in[]);

#endif                                 /* RTW_HEADER_controlEstadoSISOpid_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
