%% Blink Challenge

% The "blink_challenge" is described in the last part of the Ladyada Arduino 
% tutorial, http://www.ladyada.net/learn/arduino/ and it consists in designing 
% a circuit (and programming the board) so that the resulting device has 5 
% LEDs (connected to the digital outputs 9 to 13) and 4 modes (the user can 
% switch among them using a button connected to digital input #2):
% 
% Mode 1: All LEDs Off
% Mode 2: All LEDs On
% Mode 3: LEDs blinking simultaneously with variable frequency regulated 
%         by a potentiometer
% Mode 4: LEDs blinking one after the other (wave like) with variable speed 
%         regulated by a potentiometer
% 
% Note that the arduino must be connected in order to run this demo,
% you can use the command: a.connect('DEMO') if you don't have the 
% actual hardware.
% Also note that if the variable delay is set (with the potentiometer) to
% high values, it might be necessary to keep the button pressed longer to
% change mode. Finally, the schematics for the blink challenge is shown in
% blink_challenge_sch.mdl

%   Copyright 2011 The MathWorks, Inc.

%% create arduino object and connect to board
if exist('a','var') && isa(a,'arduino') && isvalid(a),
    % nothing to do    
else
    a=arduino('COM4');
end

%% initialize pins
disp('Initializing Pins ...');




%% start loop


while toc/60 < 1
    
    % read analog input
    ain=a.analogRead(aPin);
    v=100*ain/1024;
    
    
end



