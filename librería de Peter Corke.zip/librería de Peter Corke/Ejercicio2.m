l1=1;
l2=1;
th1=0:(pi/2)/20:pi;
th2=0:(pi/2)/20:pi;
p = pcd(l1,l2,th1,th2)
